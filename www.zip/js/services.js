angular.module('starter.services', [])

